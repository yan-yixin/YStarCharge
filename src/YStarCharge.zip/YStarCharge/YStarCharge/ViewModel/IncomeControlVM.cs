﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;
using YStarCharge.Model;
using YStarCharge.Windows;

namespace YStarCharge.ViewModel
{
    public sealed class IncomeControlVM:NotifyPropertyChanged, ICommandVM
    {
        public ObservableCollection<Income> Incomes { get; set; } = new ObservableCollection<Income>();

        public IncomeFliter Fliter { get; set; } = new IncomeFliter();

        public ICommand Add => new RelayCommand(obj => {
            EditIncomeWindow editChargeWindow = new EditIncomeWindow();
            editChargeWindow.ViewModel.Title = "新增";
            if (editChargeWindow.ShowDialog() == true)
            {
                editChargeWindow.ViewModel.Income.Number = Incomes.Count + 1;
                Incomes.Add(editChargeWindow.ViewModel.Income);
            }
        });

        public ICommand Edit => new RelayCommand(obj =>
        {
            var expend = Incomes.FirstOrDefault(e => e.IsSelected);
            if (expend == null)
            {
                MessageBox.Show("请先选中一条数据。", "提示");
                return;
            }
            EditIncomeWindow editChargeWindow = new EditIncomeWindow();
            editChargeWindow.ViewModel.Title = "编辑";
            var temp = expend;
            editChargeWindow.ViewModel.Income = new Income()
            {
                Number = temp.Number,
                Money = temp.Money,
                From = temp.From,
                Remark = temp.Remark,
                CreateAt = temp.CreateAt
            };
            if (editChargeWindow.ShowDialog() == true)
            {
                int index = Incomes.IndexOf(expend);

                Incomes.RemoveAt(index);
                editChargeWindow.ViewModel.Income.IsSelected = true;
                Incomes.Insert(index, editChargeWindow.ViewModel.Income);
            }
        });

        public ICommand Delete => new RelayCommand(obj =>
        {
            MessageBoxResult result = MessageBox.Show("确定要删除记录", "提示", MessageBoxButton.OKCancel, MessageBoxImage.Question);
            if (result == MessageBoxResult.Cancel)
            {
                return;
            }
            //无法直接删除，因为会删除不干净
            var tempExpends = Incomes.ToList();
            tempExpends.RemoveAll(te => te.IsSelected);
            Incomes.Clear();
            foreach (var ex in tempExpends)
            {
                Incomes.Add(ex);
            }
        });

        public ICommand Export => new RelayCommand(obj => {
            MessageBox.Show("导出数据");

        });

        public ICommand Query => new RelayCommand(obj => {
            List<Income> tempIncomes = Incomes.ToList();
            IEnumerable<Income> result = tempIncomes.Where(e => e.CreateAt >= Fliter.StartDate && e.CreateAt <= Fliter.EndDate).
            Where(ex => ex.Money >= Fliter.MinMoney && ex.Money <= Fliter.MaxMoney && ex.From == Fliter.From);
            if (result != null)
            {
                Incomes.Clear();
                result.ToList().ForEach(r => Incomes.Add(r));
            }

        });

        public ICommand Refresh => new RelayCommand(obj=> {

            RefreshData();
        });

        public IncomeControlVM()
        {
            Fliter.StartDate = DateTime.Now;
            Fliter.EndDate = DateTime.Now;
            RefreshData();
        }

        public void SetCheckBoxChecked(bool isCheck)
        {
            var tempExpends = Incomes.ToList();
            tempExpends.ForEach(te => te.IsSelected = isCheck);
            Incomes.Clear();
            foreach (var ex in tempExpends)
            {
                Incomes.Add(ex);
            }
        }

        private void RefreshData()
        {
            Income expend = new Income()
            {
                Number = 1,
                CreateAt = DateTime.Now.Date,
                Money = 15323.45f,
                From = IncomeFrom.工资

            };
            Income expend1 = new Income()
            {
                Number = 2,
                CreateAt = DateTime.Now.Date,
                Money = 1532,
                From = IncomeFrom.副业,
                Remark = "忘了怎么花的"
            };
            Income expend2 = new Income()
            {
                Number = 3,
                CreateAt = DateTime.Now.Date,
                Money = 15000,
                From = IncomeFrom.其他,
                Remark = "忘了怎么花的"
            };
            Incomes.Add(expend);
            Incomes.Add(expend1);
            Incomes.Add(expend2);
        }
    }
}
